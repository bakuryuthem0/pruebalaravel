A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/HrqpC.

 This demo is part of a tutorial at https://mixitup.kunkalabs.com/learn/tutorial/get-started/

Forked from [patrickkunka](/patrickkunka)'s Pen [[MixItUp] Getting Started](/patrickkunka/pen/KisAG/).