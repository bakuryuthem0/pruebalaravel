$(function(){
  $('#Container').mixItUp();
});